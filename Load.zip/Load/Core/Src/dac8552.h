#ifndef __DAC8552_H
#define __DAC8552_H

#include "stm32f1xx_hal.h"
#define   DAC8552_SYNC_LOW    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_RESET);
#define   DAC8552_SYNC_HIGH   HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
#define   DAC8552_DIN_LOW     HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_RESET);
#define   DAC8552_DIN_HIGH    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_7, GPIO_PIN_SET);
#define   DAC8552_SCLK_LOW    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
#define   DAC8552_SCLK_HIGH   HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
//__IO float usDelayBase;
void PY_usDelayTest(void);

void PY_Delay_us_t(uint32_t Delay);

void PY_usDelayOptimize(void);


void PY_Delay_us(uint32_t Delay);

void DAC8552_Set_Channel_A(uint16_t Data);

void DAC8552_Set_Channel_B(uint16_t Data);


void DAC8552_Set_Channel_AB(uint16_t Data);

void DAC8552_Set_PowerDown_1K_A(void);

void DAC8552_Set_PowerDown_1K_B(void);

void DAC8552_Set_PowerDown_1K_AB(void);

void DAC8552_Set_PowerDown_100K_A(void);

void DAC8552_Set_PowerDown_100K_B(void);

void DAC8552_Set_PowerDown_100K_AB(void);

void DAC8552_Set_PowerDown_Hz_A(void);

void DAC8552_Set_PowerDown_Hz_B(void);

void DAC8552_Set_PowerDown_Hz_AB(void);


#endif
