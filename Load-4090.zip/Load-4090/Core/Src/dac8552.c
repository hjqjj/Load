#include "dac8552.h"

//static SPI_HandleTypeDef *dac_hspi;

__IO float usDelayBase;
void PY_usDelayTest(void)
{
  __IO uint32_t firstms, secondms;
  __IO uint32_t counter = 0;

  firstms = HAL_GetTick()+1;
  secondms = firstms+1;

  while(uwTick!=firstms) ;

  while(uwTick!=secondms) counter++;

  usDelayBase = ((float)counter)/1000;
}

void PY_Delay_us_t(uint32_t Delay)
{
  __IO uint32_t delayReg;
  __IO uint32_t usNum = (uint32_t)(Delay*usDelayBase);

  delayReg = 0;
  while(delayReg!=usNum) delayReg++;
}

void PY_usDelayOptimize(void)
{
  __IO uint32_t firstms, secondms;
  __IO float coe = 1.0;

  firstms = HAL_GetTick();
  PY_Delay_us_t(1000000) ;
  secondms = HAL_GetTick();

  coe = ((float)1000)/(secondms-firstms);
  usDelayBase = coe*usDelayBase;
}


void PY_Delay_us(uint32_t Delay)
{
  __IO uint32_t delayReg;

  __IO uint32_t msNum = Delay/1000;
  __IO uint32_t usNum = (uint32_t)((Delay%1000)*usDelayBase);

  if(msNum>0) HAL_Delay(msNum);

  delayReg = 0;
  while(delayReg!=usNum) delayReg++;
}


void DAC8552_Set_Channel_A(uint16_t Data)
{
	uint8_t CMD = 0;
	uint32_t WriteData = 0;
	
	
	
	__disable_irq() ; //disable all interrupts

    CMD = 0x10;
	WriteData = (CMD<<16) | Data;

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;

    __enable_irq() ;  //enable all interrupts
}

void DAC8552_Set_Channel_B(uint16_t Data)
{
	uint8_t CMD = 0;
	uint32_t WriteData = 0;

	__disable_irq() ; //disable all interrupts

    CMD = 0x24;
	WriteData = (CMD<<16) | Data;

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;

    __enable_irq() ;  //enable all interrupts
}


void DAC8552_Set_Channel_AB(uint16_t Data)
{
	uint8_t CMD = 0;
	uint32_t WriteData = 0;

	__disable_irq() ; //disable all interrupts

    CMD = 0x10;
	WriteData = (CMD<<16) | Data;

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;


    CMD = 0x24;
	WriteData = (CMD<<16) | Data;

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;

    __enable_irq() ;  //enable all interrupts
}

void DAC8552_Set_PowerDown_1K_A(void)
{

	uint8_t CMD = 0;
	uint32_t WriteData = 0;

	__disable_irq() ; //disable all interrupts

    CMD = 0x11;
    WriteData = (CMD<<16);

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;

    __enable_irq() ;  //enable all interrupts

}

void DAC8552_Set_PowerDown_1K_B(void)
{

	uint8_t CMD = 0;
	uint32_t WriteData = 0;

	__disable_irq() ; //disable all interrupts

    CMD = 0x25;
    WriteData = (CMD<<16);

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;

    __enable_irq() ;  //enable all interrupts

}

void DAC8552_Set_PowerDown_1K_AB(void)
{

	uint8_t CMD = 0;
	uint32_t WriteData = 0;

	__disable_irq() ; //disable all interrupts

    CMD = 0x11;
    WriteData = (CMD<<16);

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;


    CMD = 0x25;
    WriteData = (CMD<<16);

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;

    __enable_irq() ;  //enable all interrupts

}


void DAC8552_Set_PowerDown_100K_A(void)
{

	uint8_t CMD = 0;
	uint32_t WriteData = 0;

	__disable_irq() ; //disable all interrupts

    CMD = 0x12;
    WriteData = (CMD<<16);

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;

    __enable_irq() ;  //enable all interrupts

}

void DAC8552_Set_PowerDown_100K_B(void)
{

	uint8_t CMD = 0;
	uint32_t WriteData = 0;

	__disable_irq() ; //disable all interrupts

    CMD = 0x26;
    WriteData = (CMD<<16);

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;

    __enable_irq() ;  //enable all interrupts

}

void DAC8552_Set_PowerDown_100K_AB(void)
{

	uint8_t CMD = 0;
	uint32_t WriteData = 0;

	__disable_irq() ; //disable all interrupts

    CMD = 0x12;
    WriteData = (CMD<<16);

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;


    CMD = 0x26;
    WriteData = (CMD<<16);

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;

    __enable_irq() ;  //enable all interrupts

}

void DAC8552_Set_PowerDown_Hz_A(void)
{

	uint8_t CMD = 0;
	uint32_t WriteData = 0;

	__disable_irq() ; //disable all interrupts

    CMD = 0x13;
    WriteData = (CMD<<16);

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;

    __enable_irq() ;  //enable all interrupts

}

void DAC8552_Set_PowerDown_Hz_B(void)
{

	uint8_t CMD = 0;
	uint32_t WriteData = 0;

	__disable_irq() ; //disable all interrupts

    CMD = 0x27;
    WriteData = (CMD<<16);

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;

    __enable_irq() ;  //enable all interrupts

}

void DAC8552_Set_PowerDown_Hz_AB(void)
{

	uint8_t CMD = 0;
	uint32_t WriteData = 0;

	__disable_irq() ; //disable all interrupts

    CMD = 0x13;
    WriteData = (CMD<<16);

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;


    CMD = 0x27;
    WriteData = (CMD<<16);

	DAC8552_SYNC_HIGH;
	PY_Delay_us_t(1);
	DAC8552_SYNC_LOW;

	for(uint8_t i=0;i<24;i++)
	{
		if( (WriteData << i) & 0x800000 )
		{
			DAC8552_DIN_HIGH;
		}
		else
		{
			DAC8552_DIN_LOW;
		}

		DAC8552_SCLK_HIGH;
		PY_Delay_us_t(1);
		DAC8552_SCLK_LOW;
		PY_Delay_us_t(1);
	}

	DAC8552_SYNC_HIGH;

    __enable_irq() ;  //enable all interrupts

}
